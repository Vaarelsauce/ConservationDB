1. SQL Creation
- Using the create SQL code provided, open up MySQL.
- Create a new database and open and run the file using MySQL.

2. Appsmith Connection
- Use the following link to use the UI for interacting with the database https://app.appsmith.com/app/conservation-database/dashboard-67d88850be9a541048e6623e?branch=main